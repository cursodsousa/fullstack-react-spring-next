(function() {
var exports = {};
exports.id = "pages/meu-componente";
exports.ids = ["pages/meu-componente"];
exports.modules = {

/***/ "./src/pages/meu-componente.tsx":
/*!**************************************!*\
  !*** ./src/pages/meu-componente.tsx ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "G:\\Curso\\vendas-app\\src\\pages\\meu-componente.tsx";

const Mensagem = props => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: props.mensagem
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 9
  }, undefined);
};

const MeuComponente = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Mensagem, {
      mensagem: 10
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (MeuComponente);

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./src/pages/meu-componente.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly92ZW5kYXMtYXBwLy4vc3JjL3BhZ2VzL21ldS1jb21wb25lbnRlLnRzeCIsIndlYnBhY2s6Ly92ZW5kYXMtYXBwL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiXSwibmFtZXMiOlsiTWVuc2FnZW0iLCJwcm9wcyIsIm1lbnNhZ2VtIiwiTWV1Q29tcG9uZW50ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUlBLE1BQU1BLFFBQWlDLEdBQUlDLEtBQUQsSUFBMEI7QUFDaEUsc0JBQ0k7QUFBQSxjQUNNQSxLQUFLLENBQUNDO0FBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxNQUFNQyxhQUFhLEdBQUcsTUFBTTtBQUN4QixzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLFFBQUQ7QUFBVSxjQUFRLEVBQUU7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsK0RBQWVBLGFBQWYsRTs7Ozs7Ozs7Ozs7QUNwQkEsbUQiLCJmaWxlIjoicGFnZXMvbWV1LWNvbXBvbmVudGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbnRlcmZhY2UgTWVuc2FnZW1Qcm9wc3tcclxuICAgIG1lbnNhZ2VtOiBudW1iZXI7XHJcbn1cclxuXHJcbmNvbnN0IE1lbnNhZ2VtOiBSZWFjdC5GQzxNZW5zYWdlbVByb3BzPiA9IChwcm9wczogTWVuc2FnZW1Qcm9wcykgPT4ge1xyXG4gICAgcmV0dXJuKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIHsgcHJvcHMubWVuc2FnZW0gfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5jb25zdCBNZXVDb21wb25lbnRlID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8TWVuc2FnZW0gbWVuc2FnZW09ezEwfSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNZXVDb21wb25lbnRlOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTs7Il0sInNvdXJjZVJvb3QiOiIifQ==